select *
from STUDENT  
inner join Take on STUDENT.SID =Take.SID;

select *
from STUDENT
natural join Take;

select *
from STUDENT
inner join Take using (SID);

select *
from Course
left join PreReq on Course.CourseNum = PreReq.CourseNum;

select DeptName, avg(Enrollment)
from Course
group by DeptNam;