SELECT * 
FROM student JOIN take ON student.SID=take.SID;

SELECT *
FROM student NATURAL JOIN take;

SELECT *
FROM student JOIN take USING(SID);

SELECT * 
FROM course LEFT JOIN prereq ON course.CourseNum=prereq.CourseNum;

SELECT deptname, avg(enrollment) AvgEnroll
FROM course
GROUP BY deptname;