drop database if exists CaseStudy2;

create database CaseStudy2;

use CaseStudy2;

create table BRANCH(
	BranchID numeric(5,1) not null,
    BranchName varchar(45) not null,
    BranchAddress varchar(45) not null,
    primary key(BranchID)
);

create table ACCOUNT(
	AccNo numeric(5,1) not null,
    AccTypeID varchar(10) not null,
    Branch varchar(45) not null,
    SSN int not null,
    Balance real not null,
    primary key(AccNo)
);

create table ACCOUNT_TYPE(
	AccTypeID varchar(10) not null,
    AccountType enum('Savings','Checking','Credit Card','Mortgage') not null,
    primary key(AccTypeID)
);

create table CUSTOMER(
	SSN numeric(9,0) not null,
    Name varchar(45) not null,
    Phone varchar(45),
    Address varchar(45) not null,
    primary key(SSN)
);

insert into CUSTOMER
values('123456789','ben',NULL,'Louisiana');

insert into ACCOUNT
values('1234','101','ruston','123456789',1234.00);

insert into ACCOUNT
values('4321','101','ruston','987654321',4321.00);