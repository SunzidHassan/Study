create database admission_data;
Create table student (
	sID varchar (15) not null,
	sName varchar(35),
	GPA decimal (3,2),
	sizeHS int,
	primary key (sID));
Create table college (
	cName varchar(35) not null,
	state varchar(15),
	enrollment int,
primary key(cName));
create table apply (
	sID varchar (15),
	cName varchar(20) ,
	major varchar(15) ,
	decision char(10),
	primary key (sID,cName,major),
	foreign key (sID) references student (sID),
	foreign key (cName) references college(cName));
    
Insert into college (cName, state, enrollment) values ("stanford", "CA",15000);
Insert into college (cName, state, enrollment) values ("Berkeley","CA",36000);
Insert into college (cName, state, enrollment) values ("MIT","MA",10000);
Insert into college (cName, state, enrollment) values ("Cornell","NY",21000);

Insert into student (sID, sName, GPA,  sizeHS ) values (123, "amy", 3.9, 1000);
Insert into student (sID, sName, GPA,  sizeHS ) values (234,"Bob",3.6,1500);
Insert into student (sID, sName, GPA,  sizeHS ) values (345, "Craig",3.5,500);
Insert into student (sID, sName, GPA,  sizeHS ) values (456,"Doris",3.9,1000);
Insert into student (sID, sName, GPA,  sizeHS ) values (567,"Edward",2.9,2000);
Insert into student (sID, sName, GPA,  sizeHS ) values (678,"Fay",3.8,200);
Insert into student (sID, sName, GPA,  sizeHS ) values (789,"Gary",3.4,800);
Insert into student (sID, sName, GPA,  sizeHS ) values (987,"Helen",3.7,800);
Insert into student (sID, sName, GPA,  sizeHS ) values (876,"Irene",3.9,400);
Insert into student (sID, sName, GPA,  sizeHS ) values (765,"Jay",2.9,1500);
Insert into student (sID, sName, GPA,  sizeHS ) values (654,"Amy",3.9,1000);
Insert into student (sID, sName, GPA,  sizeHS ) values (543,"Craig",3.4,2000);

Insert into apply (sID, cName, major, decision ) values ( 123, "stanford","CS","Y");
Insert into apply (sID, cName, major, decision ) values (123,"stanford","EE","N");
Insert into apply (sID, cName, major, decision ) values (123,"Berkeley","CS","Y"); 
Insert into apply (sID, cName, major, decision ) values (123,"Cornell","EE","Y"); 
Insert into apply (sID, cName, major, decision ) values (234,"Berkeley","Biology","N");
Insert into apply (sID, cName, major, decision ) values (345,"MIT","Bioengineering","Y");
Insert into apply (sID, cName, major, decision ) values (345,"Cornell","Bioengineering","N");
Insert into apply (sID, cName, major, decision ) values (345,"Cornell","CS","Y");
Insert into apply (sID, cName, major, decision ) values (345,"Cornell","EE","N"); 
Insert into apply (sID, cName, major, decision ) values (678,"Stanford","History","Y");
Insert into apply (sID, cName, major, decision ) values (987,"Stanford","CS","Y");
Insert into apply (sID, cName, major, decision ) values (987,"Berkeley","CS","Y");
Insert into apply (sID, cName, major, decision ) values (876,"Stanford","CS","N");
Insert into apply (sID, cName, major, decision ) values (876,"MIT","Biology","Y");
Insert into apply (sID, cName, major, decision ) values (876,"MIT","marinebiology","N");
Insert into apply (sID, cName, major, decision ) values (765,"Stanford","History","Y");
Insert into apply (sID, cName, major, decision ) values (765,"Cornell","History","N");
Insert into apply (sID, cName, major, decision ) values (765,"Cornell","Psychology","Y");
Insert into apply (sID, cName, major, decision ) values (543,"MIT","CS","N");


create database Bank_X;
Create table branch (
BranchID  numeric(10,5) ,
BranchName varchar(15),
BranchAddress varchar(20),
Primary key (BranchID));
Create table Account (
AccNo numeric (20,5),
AccTypeID varchar (15),
Branch varchar(15),
SSN  varchar(15) ,
Balance real,
Primary key (AccNo),
Foreign key (AccTypeID) references Account_Type(AccTypeID),
Foreign Key (SSN) references Customer (SSN));
Create table Account_type (
AccTypeID  varchar(15),
AccountType char(10),
Primary key (AccTypeID));
create table customer (
SSN  varchar(15) ,
Name  varchar (15),
Phone numeric(15,2),
Address varchar (25),
Primary key (SSN));

