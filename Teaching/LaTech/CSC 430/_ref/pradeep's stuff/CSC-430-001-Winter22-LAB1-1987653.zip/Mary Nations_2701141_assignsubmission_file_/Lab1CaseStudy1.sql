create database University;

use new_schema1;

create table STUDENT(
	sID varchar(10) not null primary key,
    sName varchar(45),
    GPA decimal(3,2),
    sizeHS int
);

create table COLLEGE(
	cName varchar(45) not null primary key,
    state varchar(13),
    enrollment int    
);

create table Apply(
	sID varchar(10) not null,
    cName varchar(45) not null,
    major varchar(20),
    decision varchar(20),
    foreign key (sID) references STUDENT (sID),
    foreign key (cName) references COLLEGE (cName)
);

insert into COLLEGE (cName, state, enrollment)
values 
	('Stanford', 'CA', 15000),
    ('Berkeley', 'CA', 36000),
    ('MIT', 'MA', 10000),
    ('Cornell', 'NY', 21000);
    
insert into STUDENT
values 
	(123, 'Amy', 3.9, 1000),
    (234, 'Bob', 3.6, 1500),
    (345, 'Craig', 3.5, 500),
    (456, 'Doris', 3.9, 1000),
    (567, 'Edward', 2.9, 2000),
	(678, 'Fay', 3.8, 200),
	(789, 'Gary', 3.4, 800),
	(987, 'Helen', 3.7, 800),
	(876, 'Irene', 3.9, 400),
	(765, 'Jay', 2.9, 1500),
	(654, 'Amy', 3.9, 1000),
	(543, 'Craig', 3.4, 2000);
    
insert into Apply
values
	(123, 'Stanford', 'CS', 'Y'),
	(123, 'Stanford', 'EE', 'N'),
	(123, 'Berkeley', 'CS', 'Y'),
	(123, 'Cornell', 'EE', 'Y'),
	(234, 'Berkeley', 'Biology', 'N'),
	(345, 'MIT', 'Bioengineering', 'Y'),
	(345, 'Cornell', 'Bioengineering', 'N'),
	(345, 'Cornell', 'CS', 'Y'),
	(345, 'Cornell', 'EE', 'N'),
	(678, 'Stanford', 'History', 'Y'),
	(987, 'Stanford', 'CS', 'Y'),
	(987, 'Berkeley', 'CS', 'Y'),
	(876, 'Stanford', 'CS', 'N'),
    (876, 'MIT', 'Biology', 'Y'),
	(876, 'MIT', 'marine biology', 'N'),
	(765, 'Stanford', 'History', 'Y'),
	(765, 'Cornell', 'History', 'N'),
	(765, 'Cornell', 'Psychology', 'Y'),
    (543, 'MIT', 'CS', 'N');
    

/* creates a table that shows student's accepted major/school decisions */
select c.cname, c.state, c.enrollment,
	   s.sName, s.GPA,
       a.major
from apply a
join student s
on a.sID = s.sID
join college c
on c.cName = a.cName
where a.decision = 'Y';
