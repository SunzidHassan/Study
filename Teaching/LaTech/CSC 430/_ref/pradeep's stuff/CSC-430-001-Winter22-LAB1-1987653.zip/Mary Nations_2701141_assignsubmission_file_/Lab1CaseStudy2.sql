create database Bank;

use new_schema1;

create table BRANCH(
	BranchID varchar(20) not null primary key,
    BranchName varchar(30) not null,
    BranchAddress varchar(50) not null
);

create table ACCOUNT(
	AccNo varchar(20) not null primary key,
    AccTypeID int not null,
    Branch varchar(20) not null,
    SSN varchar(9) not null,
    Balance int not null,
    foreign key (SSN) references CUSTOMER (SSN),
    foreign key (Branch) references BRANCH (BranchID)
);

create table ACCOUNT_TYPE(
	AccTypeID int not null,
    AccountType enum('Savings', 'Checking', 'Credit Card', 'Mortgage')
);

create table CUSTOMER(
	SSN varchar(9) not null primary key,
    Name varchar(30) not null,
    Phone varchar(11),
    Address varchar(30)
);

insert into BRANCH
values
	(123456, 'Chase', '123 Candy Cane Lane'),
    (654321, 'Ally', 'Online Only Road'),
    (987654, 'SomeBank', '543 Random Street');
    
insert into CUSTOMER
values
	('123456789', 'Jane Doe', null,'2308 California'),
    ('987654321', 'Johnathan Doel', '6012559591', '820 West Ave');

insert into ACCOUNT
values
	('321', 1, '654321', '123456789', 1000),
    ('123', 1, '654321', '987654321', 500),
    ('741', 2, '654321', '123456789', 25),
    ('147', 1, '987654', '987654321', 5000),
    ('963', 3, '123456', '123456789', 10000);
    
insert into ACCOUNT_TYPE
values
	(1, 'Savings'),
    (2, 'Checking'),
    (3, 'Credit Card'),
    (4, 'Mortgage');
  
/* shows all accounts */
select a.AccNo, act.AccountType,
	   c.SSN, c.Name, c.Phone,
       b.BranchName
from account a
join account_type act
on a.AccTypeID = act.AccTypeID
join customer c
on c.SSN = a.SSN
join branch b
on b.BranchID = a.Branch