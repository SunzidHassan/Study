create database Lab1Case1;
Use Lab1Case1;

create table STUDENT (
sID Numeric(3,0) not null PRIMARY KEY ,
sName varchar(30) not null ,
GPA Float(3) ,
sizeHS int );

create table COLLEGE (
cName varchar(30) not null PRIMARY KEY ,
state char(2) not null ,
enrollment int );

create table Apply (
sID Numeric(3,0) not null ,
cName varchar(30) not null , 
major varchar(20) not null, 
decision char(1) ,
PRIMARY KEY (sID , cName, major) ,  
FOREIGN KEY (sID) REFERENCES STUDENT , 
FOREIGN KEY (cName) REFERENCES COLLEGE );

Insert Into COLLEGE(cName, state, enrollment) Values('Standford', 'CA', 15000);
Insert Into COLLEGE(cName, state, enrollment) Values('Berkeley', 'CA', 36000);
Insert Into COLLEGE(cName, state, enrollment) Values('MIT', 'MA', 10000);
Insert Into COLLEGE(cName, state, enrollment) Values('Cornell', 'NY', 21000);

Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(123, 'Amy', 3.9, 1000);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(234, 'Bob', 3.6, 1500);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(345, 'Craig', 3.5, 500);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(456, 'Doris', 3.9, 1000);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(567, 'Edward', 2.9, 2000);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(678, 'Fay', 3.8, 200);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(789, 'Gary', 3.4, 800);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(987, 'Helen', 3.7, 800);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(876, 'Irene', 3.9, 400);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(765, 'Jay', 2.9, 1500);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(654, 'Amy', 3.9, 1000);
Insert Into STUDENT(sID, sName, GPA, sizeHS) Values(543, 'Craig', 3.4, 2000);



Insert Into Apply(sID, cName, major, decision) Values(123, 'Stanford', 'CS', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(123, 'Stanford', 'EE', 'N');
Insert Into Apply(sID, cName, major, decision) Values(123, 'Berkeley', 'CS', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(123, 'Cornell', 'EE', 'Y');

Insert Into Apply(sID, cName, major, decision) Values(234, 'Berkeley', 'Biology', 'N');

Insert Into Apply(sID, cName, major, decision) Values(345, 'MIT', 'Bioengineering', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(345, 'Cornell', 'Bioengineering', 'N');
Insert Into Apply(sID, cName, major, decision) Values(345, 'Cornell', 'CS', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(345, 'Cornell', 'EE', 'N');

Insert Into Apply(sID, cName, major, decision) Values(678, 'Stanford', 'History', 'Y');

Insert Into Apply(sID, cName, major, decision) Values(987, 'Stanford', 'CS', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(987, 'Berkeley', 'CS', 'Y');

Insert Into Apply(sID, cName, major, decision) Values(876, 'Stanford', 'Biology', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(876, 'MIT', 'Marine Biology', 'N');

Insert Into Apply(sID, cName, major, decision) Values(765, 'Stanford', 'History', 'Y');
Insert Into Apply(sID, cName, major, decision) Values(765, 'Cornell', 'History', 'N');
Insert Into Apply(sID, cName, major, decision) Values(765, 'Cornell', 'Psychology', 'Y');

Insert Into Apply(sID, cName, major, decision) Values(543, 'MIT', 'CS', 'N');





