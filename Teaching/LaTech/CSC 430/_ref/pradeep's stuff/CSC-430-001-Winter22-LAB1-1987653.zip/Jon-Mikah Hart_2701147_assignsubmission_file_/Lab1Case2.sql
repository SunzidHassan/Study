create database Lab1Case2;
Use Lab1Case2;

create table BRANCH (
BranchID int not null PRIMARY KEY,
BranchName varchar(30) not null,
BranchAddress varchar(50) not null);

create table ACCOUNT (
AccNo int not null PRIMARY KEY, 
AccTypeID int not null,
BranchName varchar(30) not null ,
SSN char(10) not null ,
Balance Float(3) not null ,
FOREIGN KEY (AccTypeID) REFERENCES ACCOUNT_TYPE , 
FOREIGN KEY (SSN) REFERENCES CUSTOMER , 
FOREIGN KEY (BranchName) REFERENCES BRANCH );

create table ACCOUNT_TYPE (
AccTypeID int not null PRIMARY KEY,
AccountType varchar(15) not null );

create table CUSTOMER (
SSN char(10) not null PRIMARY KEY,
Name varchar(30) not null ,
Phone char(12)  , 
Address varchar(50) not null );


Insert Into BRANCH(BranchID, BranchName, BranchAddress) Values(1234, 'BankX01', '111 One St');

Insert Into BRANCH(BranchID, BranchName, BranchAddress) Values(1235, 'BankX02', '222 Two St');

Insert Into CUSTOMER(SSN, Name, Phone, Address) Values(1234567890, 'Jon', 318-000-5555, '444 Four St'); 
Insert Into ACCOUNT_TYPE(AccTypeID, AccountType) Values(001, 'Checkings');
Insert Into ACCOUNT(AccNo, AccTypeID, BranchName, SSN, Balance) Values(987, 001, 'BankX01', 1234567890, 140.45);
Insert Into ACCOUNT_TYPE(AccTypeID, AccountType) Values(010, 'Credit Card');
Insert Into ACCOUNT(AccNo, AccTypeID, BranchName, SSN, Balance) Values(987, 010, 'BankX01', 1234567890, 700.00);


Insert Into CUSTOMER(SSN, Name, Address) Values(0987654321, 'Charles', '333 Three St'); 
Insert Into ACCOUNT_TYPE(AccTypeID, AccountType) Values(002, 'Checkings');
Insert Into ACCOUNT(AccNo, AccTypeID, BranchName, SSN, Balance) Values(345, 002, 'BankX01', 0987654321, 30.34);
Insert Into ACCOUNT_TYPE(AccTypeID, AccountType) Values(003, 'Savings');
Insert Into ACCOUNT(AccNo, AccTypeID, BranchName, SSN, Balance) Values(346 , 003, 'BankX02', 0987654321, 500.00);
