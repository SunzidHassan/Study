use newdbW22_v1;
CREATE TABLE BRANCH (
BRANCHID varchar(10) not null PRIMARY KEY,
BRANCHNAME varchar (30),
BRANCHADDRESS varchar (30)
);
CREATE TABLE ACCOUNT (
ACCNO varchar(10) not null PRIMARY KEY,
ACCTYPEID varchar (15),
BRANCH varchar(8),
SSN varchar(9),
BALANCE varchar(15)
);
CREATE TABLE ACCOUNT_TYPE (
ACCTYPEID varchar(10) not null PRIMARY KEY,
ACCTTYPE ENUM('Saveings','Checking','Credit Card','Mortgage')
);
CREATE TABLE CUSTOMER (
SSN varchar(10),
CNAME varchar(15),
PHONE varchar(8),
ADDRESS varchar(20)
);