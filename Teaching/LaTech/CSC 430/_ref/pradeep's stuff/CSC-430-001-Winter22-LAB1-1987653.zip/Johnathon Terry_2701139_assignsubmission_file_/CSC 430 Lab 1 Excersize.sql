create database newdbW222;
Use newdbW222;

create table BRANCH(
BranchID varchar(45) not null primary key,
BranchName varchar(45) not null,
BranchAddress varchar(45) not null);

create table ACCOUNT(
AccNo varchar(45) not null primary key,
AccTypeID varchar(45) not null,
Branch varchar(45) not null,
SSN varchar(45) not null,
Balance varchar(45) not null);

create table ACCOUNT_Type(
AccTypeID varchar(45) not null,
AccountType Enum('Savings', 'Checking', 'CreditCard', 'Mortgage') not null);

create table CUSTOMER(
SSN varchar(45) not null,
CName varchar(45) not null,
Phone varchar(45),
Address varchar(45) not null);