1)	create view Student_det as 
select name as sname,address as saddress 
from student;

2)	CREATE DEFINER=`root`@`localhost` TRIGGER `professor_BEFORE_INSERT` BEFORE INSERT ON `professor` FOR EACH ROW BEGIN
	declare msg varchar(255); 
	if (DateDiff(Now(),new.DateOfBirth)/365 <18) then
		set msg = 'error'; 
        		signal sqlstate '45000' set message_text = msg; 
	END IF;
END
3) create view Student_details2 as
select s.*,t.CourseNum,t.DeptName,t.Grade,t.ProfessorEval,c.CourseName,c.ClassRoom,c.Enrollment
from course c,TAKE t, STUDENT s
where c.CourseNum= t.CourseNum and s.SID = t.SID;
4) CREATE DEFINER=`root`@`localhost` TRIGGER `take_BEFORE_DELETE` BEFORE DELETE ON `take` FOR EACH ROW BEGIN
    insert into TAKE_BACKUP
		(SID, CourseNum, DeptName, Grade, ProfessorEval)
    values(old.SID, old.CourseNum, old.DeptName, old.Grade, old.ProfessorEval);
END
5) CREATE DEFINER=`root`@`localhost` TRIGGER `take_BEFORE_UPDATE` BEFORE UPDATE ON `take` FOR EACH ROW BEGIN
	insert into Grade_changed 
		(SID,  OLDGrade, NEWGrade)
    values(old.SID, old.Grade, New.Grade);
END
