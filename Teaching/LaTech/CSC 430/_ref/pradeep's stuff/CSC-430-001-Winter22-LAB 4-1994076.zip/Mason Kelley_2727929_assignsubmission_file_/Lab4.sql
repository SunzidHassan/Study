CREATE VIEW STUDENTS (sname, saddress) as
SELECT Name, Address
FROM student;

CREATE DEFINER=`root`@`localhost` TRIGGER `professor_BEFORE_INSERT` BEFORE INSERT ON `professor` FOR EACH ROW BEGIN
	declare msg varchar(255);
	IF (DateDiff(Now(),professor.DateOfBirth)/365 < 18) THEN
		set msg = 'Invalid Date of Birth';
		signal sqlstate '45000' set message_text = msg;
	END IF;
END;

CREATE VIEW SCHEDULE AS
SELECT student.SID SID, student.Name Name, student.Address Address, take.CourseNum CourseNum, take.DeptName DeptName, take.Grade Grade, take.ProfessorEval ProfEval, course.CourseName CourseName, course.ClassRoom Classroom, course.Enrollment Enrollment
FROM student INNER JOIN take ON student.SID=take.SID
JOIN course ON take.CourseNum=course.CourseNum AND take.DeptName=course.DeptName;


DROP TABLE IF EXISTS TAKE_BACKUP;
CREATE TABLE TAKE_BACKUP (SELECT * FROM TAKE WHERE 1=1);
CREATE DEFINER = CURRENT_USER TRIGGER `studentdbw22`.`take_AFTER_DELETE_1` AFTER DELETE ON `take` FOR EACH ROW
BEGIN

END;

CREATE DEFINER=`root`@`localhost` TRIGGER `take_AFTER_UPDATE` AFTER UPDATE ON `take` FOR EACH ROW BEGIN
	IF((SID, old.Grade, new.Grade) NOT IN (SELECT * FROM GRADE_CHANGED)) THEN
		INSERT INTO GRADE_CHANGED values 
        (SID, old.Grade, new.Grade);
    END IF;
END


