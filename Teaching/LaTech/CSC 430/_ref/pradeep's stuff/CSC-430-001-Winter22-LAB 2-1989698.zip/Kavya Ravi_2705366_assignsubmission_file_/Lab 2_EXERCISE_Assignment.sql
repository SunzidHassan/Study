select take.Grade, student.Name
from take,student
where (student.SID = take.SID) and grade>=3.0;

select round((take.grade+take.ProfessorEval)/2,2) as avg
from take
order by avg ASC; 



select S.Name , S.SID
from  (select * from take where DeptName="Education" ) as Take,student as S
where (S.SID = take.SID) and Take.CourseNum=101;

Select * from Take where CourseNum in 
(select CourseNum from Course
where CourseNum not in (Select CourseNum from PreReq));

Select CourseName
from Course where exists (select CourseNum from PreReq P 
where P.CourseNum=Course.CourseNum);
