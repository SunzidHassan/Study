
select S.Name,t.Grade from Take t, STUDENT S where Grade>3.0 and S.SID=t.SID;

select Round((t.Grade+t.ProfessorEval)/2,2) As Average  from Take t  order by Average ASC;

select S.NAME,S.SID 
from  (select * from Take where DeptName="Education" ) as Take, STUDENT as S where S.SID=Take.SID and Take.CourseNum=101;

SELECT * FROM  take WHERE (take.CourseNum, take.DeptName)  not in (select prereq.CourseNum, prereq.DeptName FROM prereq);

Select CourseName from Course where exists (select CourseNum from PreReq P where P.CourseNum=Course.CourseNum);