SELECT student.Name, take.Grade
FROM student, take
WHERE student.SID = take.SID AND take.Grade > 3.0;

SELECT (take.Grade + take.ProfessorEval) / 2 as GradeAVG
FROM student, take
WHERE student.SID = take.SID
ORDER BY GradeAVG ASC;

SELECT S.SID
FROM STUDENT  S, (SELECT * FROM  TAKE WHERE  TAKE.COURSENUM=101 AND TAKE.DEPTNAME='Education') T
WHERE S.SID=T.SID;

SELECT DeptName, CourseNum
FROM  take
WHERE CONCAT(take.CourseNum, take.DeptName) NOT IN (SELECT CONCAT(prereq.CourseNum, prereq.DeptName) FROM prereq, course WHERE prereq.CourseNum=course.CourseNum and prereq.DeptName=course.deptName);

SELECT CourseNum, DeptName
FROM prereq
WHERE EXISTS (SELECT PREREQNUMBER FROM prereq);







