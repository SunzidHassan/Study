var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.watchPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";}
    }

function showPosition(position){
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;
    var location = new location(lat, lng, {type: "text/plain;charset=utf-8"});
    JSON.stringify(location);
}