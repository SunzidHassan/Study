// Google Map
var map;

// markers for map
var markers = [];

// execute when the DOM is fully loaded
$(function() {
    // options for map
    // https://developers.google.com/maps/documentation/javascript/reference#MapOptions
    var options = {
        center: {lat: 22.9005, lng: 89.5024}, // KUET
        disableDefaultUI: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        maxZoom: 14,
        panControl: true,
        zoom: 13,
        zoomControl: true
    };
    
    // get DOM node in which map will be instantiated
    var canvas = $("#map-canvas").get(0);

    // instantiate map
    map = new google.maps.Map(canvas, options);
    
    var marker = new google.maps.Marker({
        position: {lat: 22.9005, lng: 89.5024},
        map: map
        });
        marker.setMap(map);
});