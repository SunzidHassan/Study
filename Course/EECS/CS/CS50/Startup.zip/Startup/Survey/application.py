import os
import re
from flask import Flask, jsonify, render_template, request, url_for
from flask_jsglue import JSGlue

from cs50 import SQL
from helpers import lookup

# configure application
app = Flask(__name__)
JSGlue(app)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# configure CS50 Library to use SQLite database
db = SQL("sqlite:///department.db")

@app.route("/")
def index():
    """Render map."""
    return render_template("index.html")

@app.route("/map")
def map():
    return render_template("map.html")
    
@app.route("/survey", methods =["GET", "POST"])
def form():
    if request.method == "GET":
        return render_template("survey.html")
        
@app.route("/data")
def data():
    return render_template("data.html")
    
@app.route("/logout")
def logout():
    return render_template("logout.html")