// Google Map
var map;

//array to store many markers
var markers = [];

//why: when map.html is loaded, this'll fill the div with map
$(function(){
    var mapOpt = {
        center: {lat: 22.9005, lng: 89.5024}, //KUET
        disableDefaultUI: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        maxZoom: 14,
        panControl: true,
        zoom: 13,
        zoomControl: true
    };
    
    // get DOM node in which map will be instantiated
    var canvus = $("map-canvas").get(0);
    
    // instantiate map
    map = new google.maps.Map(canvus, mapOpt);
    
    // code change of UI once map is fully loaded(idle)
    google.maps.event.addListenerOnce(map, "idle", configure);
});


// this'll add marker for survey in map
function addMarker(survey){
    var coordinates = new google.maps.coordinates(survey["latitude"], survey["longitude"]);
    
    var markerOpt = {
        position: coordinates,
        map: map,
        label: survey["survey_ID"],
    }
    
    markers = new google.maps.Marker(markerOpt)
}

// configure application
function configure(){
    google.maps.event.addListener(map, "dragened", function(){
        if(!info.getMap || !)
    })
}