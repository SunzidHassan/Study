myTechEmail = 'ask021@latech.edu' #only your email id, omit @latech.edu
# 20 points

# x^3 problem and function (in python that is x**3)

def xpower3(rmax):
    I = {i for i in range(rmax)}
    S = set(range(rmax)) #"replace this with your def"
    IxS = {(i,s) for i in I for s in S} #"replace this with your def"
    # i^3 is i to power of 3 problem
    Q = {(i,s) for (i,s) in IxS if (i**3==s)} #"replace this with your def"
    # i^3 funciton based on Q
    D= dict(Q)
    Qf = lambda i: D[i]  #"based on Q, return the solution for i"

    return I,S,IxS,Q,Qf

if __name__ == '__main__':
    # your testing codes within this if
    pass # replay this line with your code

