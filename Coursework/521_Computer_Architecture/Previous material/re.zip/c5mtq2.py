myTechEmail = 'ask021@latech.edu' #only your email id, omit @latech.edu
from bcom import *

# 15 points

# 2(b). This question is based on your state diagram on part A 2(a).
# Based on your state diagram, code a TM, that can be run on bcom.py.



Q2q0 = 0 # e.g. Q2q0 = 0

Q2df = {(0,0):(3,0,R), (0,1):(5,1,R), (0,2):(1,2,R), (0,b):(h,b,R),(3,0):(3,0,R), (3,1):(5,1,R), (3,2):(1,2,R), (3,b):(4,0,R), (0,2):(1,2,R),(1,0):(1,0,R),(1,1):(1,1,R), (1,2):(1,2,R), (1,b):(2,b,R), (2,0):(h,2,R), (2,1):(h,2,R), (2,2):(h,2,R), (2,b):(h,2,R), (4,0):(h,0,R), (4,1):(h,0,R), (4,2):(h,0,R), (4,b):(h,0,R),(5,0):(5,0,R), (5,1):(5,1,R), (5,2):(1,2,R), (5,b):(6,b,R), (6,0):(h,1,R), (6,1):(h,1,R), (6,2):(h,1,R), (6,b):(h,1,R) } # e.g. Q2df = {(0,0):(0,0,R), ...}


if __name__ == '__main__':
    # your testing codes within this if
    pass # replay this line with your code
