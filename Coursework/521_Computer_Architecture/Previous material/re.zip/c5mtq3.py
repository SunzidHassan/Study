myTechEmail = 'ask021@latech.edu' #only your email id, omit @latech.edu

# 15 points

def implies():
    # return a true table for "A implies B"
    # where A, B, can be True or False
    impliesTT = {(False,False): True, (False,True):True, (True, False):False, (True, True): True} # e.g. {(Flase,Flase):True, ...}
    return impliesTT # note: returning a dict

def imply(A, B):
    d= implies()
    return d[A,B]
    # define a function that return the result of "A implies B"
    #return res in implies().impliesTT[A,B]"replace this string with your code"

if __name__ == '__main__':
    imply(1,0)
    imply(1,1)
    imply(False,True)
    # your testing codes within this if
    pass # replay this line with your code

