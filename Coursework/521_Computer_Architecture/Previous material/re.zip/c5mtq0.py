# should not contain sytax error
myName = 'Khan, Adiba' # your name inside the ' '
myTechID = '10401790'
myTechEmail = 'ask021@latech.edu' #only your email id omit @latech.edu
